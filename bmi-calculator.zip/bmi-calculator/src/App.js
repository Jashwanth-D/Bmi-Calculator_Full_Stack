import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import BMICalculator from './pages/BMICalculator';
import EditBMI from './pages/EditBMI';
import Home from './pages/Home';
import Login from './pages/login';
import Signup from './pages/Signup';
function App() {
return <Router>
  <Routes>
    <Route path='/' element={<Login/>}/>
    <Route path='/register' element={<Signup/>}/>
    <Route path='/Home' element={<Home />} />
    <Route path='/check' element={<BMICalculator />} />
    <Route path='/edit/:slug' element={<EditBMI />} />
  </Routes>
</Router>
}

export default App;