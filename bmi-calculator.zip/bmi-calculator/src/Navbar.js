import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div className="navbar">
    <Link to="/home">home</Link>
    <Link to="/check">Check</Link>
    <Link to="/">Logout</Link>
    </div>
  );
}

export default Navbar;